import { BadRequestException, Injectable } from '@nestjs/common';
import { BlockchainService } from '../blockchain/blockchain.service';
import { AuditService } from '../audit/audit.service';
import { MqttService } from '../mqtt/mqtt.service';
import { MQTT_TOPICS } from '../mqtt/mqtt-topics';
import { SupabaseClientService } from '../supabase/supabase-client.service';
import { NotificationService } from './notification.service';
import type { RevocationGround as BlockchainRevocationGround } from '../blockchain/types';

/**
 * Statutory grounds for revocation under the Nigerian Land Use Act (1978) s.28.
 * Maps to the numeric `RevocationGround` in blockchain/types.ts:
 *   'OverridingPublicInterest'    → 0
 *   'BreachOfStatutoryCondition'  → 1
 *
 * References: Requirements 4.7, 4.8, 4.9
 */
export type RevocationGround =
  | 'OverridingPublicInterest'
  | 'BreachOfStatutoryCondition';

const GROUND_INDEX: Record<RevocationGround, BlockchainRevocationGround> = {
  OverridingPublicInterest: 0,
  BreachOfStatutoryCondition: 1,
};

@Injectable()
export class RevocationService {
  constructor(
    private readonly blockchainService: BlockchainService,
    private readonly auditService: AuditService,
    private readonly mqttService: MqttService,
    private readonly supabase: SupabaseClientService,
    private readonly notificationService: NotificationService,
  ) {}

  /**
   * Statutorily revoke a land title.
   *
   * Steps:
   *  1. Call `BlockchainService.revokeTitle` with the numeric ground index.
   *  2. Update `land_titles` row: set `status = 'revoked'`, `revoked_at = now()`.
   *  3. Update `parcels` row(s): set `status = 'reverted'` WHERE `token_id = tokenId`.
   *  4. Append an audit trail entry for `STATUTORY_REVOCATION`.
   *  5. Publish `TITLE_REVOKED` MQTT event at QoS 2.
   *  6. Send out-of-band notifications (stub).
   *
   * @param tokenId           The ERC-721 token ID to revoke (string representation of BigInt).
   * @param ground            Statutory revocation ground.
   * @param governorId        Supabase auth UUID of the acting governor.
   * @param governorPrivateKey Hex private key of the Governor's wallet.
   */
  async revoke(
    tokenId: string,
    ground: RevocationGround,
    governorId: string,
    governorPrivateKey: string,
  ): Promise<void> {
    if (!/^[1-9]\d*$/.test(tokenId)) {
      throw new BadRequestException('tokenId must be a positive integer');
    }

    if (!Object.prototype.hasOwnProperty.call(GROUND_INDEX, ground)) {
      throw new BadRequestException('Unsupported statutory revocation ground');
    }

    // Step 1 — On-chain revocation
    const groundIndex = GROUND_INDEX[ground];
    const txHash = await this.blockchainService.revokeTitle(
      BigInt(tokenId),
      groundIndex,
      governorPrivateKey,
    );

    // Step 2 — Mark land_titles as revoked
    const { error: titleError } = await this.supabase.raw
      .from('land_titles')
      .update({ status: 'revoked', revoked_at: new Date().toISOString() })
      .eq('token_id', tokenId);

    if (titleError) {
      throw new Error(`Failed to update land_titles: ${titleError.message}`);
    }

    // Step 3 — Revert associated parcels
    const { error: parcelError } = await this.supabase.raw
      .from('parcels')
      .update({ status: 'reverted' })
      .eq('token_id', tokenId);

    if (parcelError) {
      throw new Error(`Failed to update parcels: ${parcelError.message}`);
    }

    // Step 4 — Audit trail
    await this.auditService.record({
      entityId: tokenId,
      actorId: governorId,
      action: 'STATUTORY_REVOCATION',
      outcome: 'REVOKED',
      metadata: { ground, txHash },
    });

    // Step 5 — MQTT event (QoS 2, as defined in MQTT_TOPICS.TITLE_REVOKED)
    await this.mqttService.publish(
      MQTT_TOPICS.TITLE_REVOKED.topic,
      {
        tokenId,
        ground,
        revokedBy: governorId,
        timestamp: new Date().toISOString(),
      },
      2,
    );

    // Step 6 — Out-of-band notification (stub)
    await this.notificationService.notifyRevocation(tokenId, ground);
  }

  /**
   * Perform a registry-controlled title transfer via LandRegistry.registryTransfer().
   */
  async transferTitle(
    tokenId: string,
    toWallet: string,
    registrarId: string,
    newOwnerId?: string,
  ): Promise<{
    oldTokenId: string;
    newTokenId: string;
    from: string;
    to: string;
    txHash: string;
  }> {
    if (!/^[1-9]\d*$/.test(tokenId)) {
      throw new BadRequestException('tokenId must be a positive integer');
    }

    if (!/^0x[0-9a-fA-F]{40}$/.test(toWallet)) {
      throw new BadRequestException('toWallet must be a valid EVM address');
    }

    const tokenIdBigInt = BigInt(tokenId);
    const revoked = await this.blockchainService.isRevoked(tokenIdBigInt);
    if (revoked) {
      throw new BadRequestException('Cannot transfer a statutorily revoked title');
    }

    const fromWallet = await this.blockchainService.ownerOf(tokenIdBigInt);
    const transferResult = await this.blockchainService.registryTransfer(
      tokenIdBigInt,
      fromWallet,
      toWallet,
    );

    const newTokenIdStr = transferResult.newTokenId.toString();

    const { error: titleError } = await this.supabase.raw
      .from('land_titles')
      .update({
        token_id: newTokenIdStr,
        tx_hash: transferResult.txHash,
        ...(newOwnerId !== undefined && { owner_id: newOwnerId }),
      })
      .eq('token_id', tokenId);

    if (titleError) {
      throw new Error(`Failed to update land_titles on transfer: ${titleError.message}`);
    }

    const { data: parcelRows, error: parcelError } = await this.supabase.raw
      .from('parcels')
      .update({ token_id: newTokenIdStr })
      .eq('token_id', tokenId)
      .select('id');

    if (parcelError) {
      throw new Error(`Failed to update parcels on transfer: ${parcelError.message}`);
    }

    const parcelId =
      Array.isArray(parcelRows) && parcelRows.length > 0
        ? String((parcelRows[0] as { id: string }).id)
        : tokenId;

    await this.auditService.record({
      entityId: tokenId,
      actorId: registrarId,
      action: 'REGISTRY_TRANSFER',
      outcome: 'TRANSFERRED',
      metadata: {
        oldTokenId: tokenId,
        newTokenId: newTokenIdStr,
        from: fromWallet,
        to: toWallet,
        txHash: transferResult.txHash,
      },
    });

    await this.mqttService.publish(
      MQTT_TOPICS.TITLE_ISSUED.topic,
      {
        tokenId: newTokenIdStr,
        owner: toWallet,
        parcelId,
        timestamp: new Date().toISOString(),
      },
      MQTT_TOPICS.TITLE_ISSUED.qos,
    );

    return {
      oldTokenId: tokenId,
      newTokenId: newTokenIdStr,
      from: fromWallet,
      to: toWallet,
      txHash: transferResult.txHash,
    };
  }
}
