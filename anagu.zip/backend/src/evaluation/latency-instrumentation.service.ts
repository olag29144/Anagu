import { Injectable } from '@nestjs/common';
import { performance } from 'perf_hooks';

export interface StageTiming {
  t_gis: number;
  t_oracle: number;
  t_contract: number;
  t_nft: number;
  t_sync: number;
  T_total: number;
}

export interface StageHooks {
  gisVerify?: () => Promise<unknown>;
  oracleVerify?: () => Promise<unknown>;
  executeSmartContract?: () => Promise<unknown>;
  issueNFT?: () => Promise<unknown>;
  publishMQTT?: () => Promise<unknown>;
}

export interface BenchmarkStats {
  mean: number;
  sd: number;
}

export interface LatencyBenchmarkResult {
  runs: number;
  stages: {
    t_gis: BenchmarkStats;
    t_oracle: BenchmarkStats;
    t_contract: BenchmarkStats;
    t_nft: BenchmarkStats;
    t_sync: BenchmarkStats;
    T_total: BenchmarkStats;
  };
}

/**
 * LatencyInstrumentationService — benchmarks the five pipeline stages using
 * `performance.now()` as required by Requirement 10.3.
 *
 * Each stage is simulated with representative processing times:
 *   t_gis      ~50 ms  (Supabase PostGIS spatial verification)
 *   t_oracle   ~30 ms  (ownership oracle cross-check)
 *   t_contract ~120 ms (Besu smart contract execution)
 *   t_nft      ~80 ms  (ERC-721 NFT issuance and Supabase update)
 *   t_sync     ~10 ms  (MQTT event publication)
 *
 * In production these would delegate to the real service implementations.
 *
 * Requirements: 10.3, 10.6
 */
@Injectable()
export class LatencyInstrumentationService {
  /**
   * Simulate one complete timed registration transaction through all five stages.
   * Returns the wall-clock time (ms) for each stage and the cumulative total.
   */
  async timedRegistration(hooks?: StageHooks): Promise<StageTiming> {
    const t0 = performance.now();
    await (hooks?.gisVerify ? hooks.gisVerify() : this.simulateStage(50)); // GIS spatial verification
    const t_gis = performance.now() - t0;

    const t1 = performance.now();
    await (hooks?.oracleVerify ? hooks.oracleVerify() : this.simulateStage(30)); // Oracle ownership check
    const t_oracle = performance.now() - t1;

    const t2 = performance.now();
    await (hooks?.executeSmartContract ? hooks.executeSmartContract() : this.simulateStage(120)); // Smart contract execution
    const t_contract = performance.now() - t2;

    const t3 = performance.now();
    await (hooks?.issueNFT ? hooks.issueNFT() : this.simulateStage(80)); // NFT issuance
    const t_nft = performance.now() - t3;

    const t4 = performance.now();
    await (hooks?.publishMQTT ? hooks.publishMQTT() : this.simulateStage(10)); // MQTT synchronisation
    const t_sync = performance.now() - t4;

    return {
      t_gis,
      t_oracle,
      t_contract,
      t_nft,
      t_sync,
      T_total: t_gis + t_oracle + t_contract + t_nft + t_sync,
    };
  }

  /**
   * Run `n` timed registrations and compute mean ± standard deviation per stage.
   * Requirement 10.3 mandates at least 30 runs.
   */
  async runLatencyBenchmark(
    n = 30,
    hooksFactory?: () => StageHooks,
  ): Promise<LatencyBenchmarkResult> {
    this.assertRunCount(n);
    const timings: StageTiming[] = [];
    for (let i = 0; i < n; i++) {
      timings.push(
        hooksFactory
          ? await this.timedRegistration(hooksFactory())
          : await this.timedRegistration(),
      );
    }

    return {
      runs: n,
      stages: {
        t_gis: this.stats(timings.map((r) => r.t_gis)),
        t_oracle: this.stats(timings.map((r) => r.t_oracle)),
        t_contract: this.stats(timings.map((r) => r.t_contract)),
        t_nft: this.stats(timings.map((r) => r.t_nft)),
        t_sync: this.stats(timings.map((r) => r.t_sync)),
        T_total: this.stats(timings.map((r) => r.T_total)),
      },
    };
  }

  computeImprovementPercentage(
    proposedMeanMs: number,
    baselineMeanMs: number,
  ): number {
    if (
      !Number.isFinite(proposedMeanMs) ||
      !Number.isFinite(baselineMeanMs) ||
      baselineMeanMs <= 0
    ) {
      return 0;
    }

    const improvement = ((baselineMeanMs - proposedMeanMs) / baselineMeanMs) * 100;
    return Number(improvement.toFixed(2));
  }

  /**
   * Run a synchronous baseline benchmark representing the conventional paper-based
   * process: only a document-presence check with no async I/O.
   */
  runBaselineBenchmark(n = 30): LatencyBenchmarkResult {
    this.assertRunCount(n);
    const times: number[] = [];

    for (let i = 0; i < n; i++) {
      const t = performance.now();
      // Baseline: purely synchronous document-presence check — no async operations
      const docs = { titleDeed: 'x', surveyPlan: 'x', identityDocument: 'x' };
      void docs;
      times.push(performance.now() - t);
    }

    const s = this.stats(times);
    return {
      runs: n,
      stages: {
        t_gis: s,
        t_oracle: s,
        t_contract: s,
        t_nft: s,
        t_sync: s,
        T_total: s,
      },
    };
  }

  // ---------------------------------------------------------------------------
  // Private helpers
  // ---------------------------------------------------------------------------

  private assertRunCount(n: number): void {
    if (!Number.isInteger(n) || n < 1) {
      throw new Error('Benchmark run count must be a positive integer');
    }
  }

  /**
   * Simulates a pipeline stage with a given approximate duration (ms) plus
   * ±10% Gaussian-like jitter to produce realistic variance.
   */
  private async simulateStage(approxMs: number): Promise<void> {
    const jitter = (Math.random() - 0.5) * approxMs * 0.2;
    await new Promise<void>((resolve) =>
      setTimeout(resolve, Math.max(1, approxMs + jitter)),
    );
  }

  /** Compute mean and standard deviation, rounded to 3 decimal places. */
  private stats(values: number[]): BenchmarkStats {
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const variance =
      values.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / values.length;
    return {
      mean: parseFloat(mean.toFixed(3)),
      sd: parseFloat(Math.sqrt(variance).toFixed(3)),
    };
  }
}
